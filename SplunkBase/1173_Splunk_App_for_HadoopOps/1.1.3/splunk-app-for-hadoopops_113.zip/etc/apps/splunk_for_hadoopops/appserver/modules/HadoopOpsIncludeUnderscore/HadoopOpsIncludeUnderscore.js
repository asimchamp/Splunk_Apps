Splunk.Module.HadoopOpsIncludeUnderscore = $.klass(Splunk.Module, {
    initialize: function($super, container) {
        $super(container);
        this.hide('HIDDEN MODULE KEY');
    }
});

