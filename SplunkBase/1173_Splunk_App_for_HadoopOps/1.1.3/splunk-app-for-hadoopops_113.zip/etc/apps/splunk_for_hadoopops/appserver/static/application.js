// determine Splunk version
var splVersion = 0,
    bodyClass = $('body').attr('class'),
    hasSplVersion = ( bodyClass.indexOf("splVersion-") >= 0 ) ? true : false,
    splVersionRex = /splVersion-([0-9]+)/,
    match =  splVersionRex.exec(bodyClass),
    // deferred promise ... deal with async loading in 6.0+
    pageLoading = $.Deferred(),
    poller; 

if(hasSplVersion && match !== null) {
    // if we can extract the splVersion class attribute from the body class
    // then we will assign it here. Otherwise version remains = 0
    splVersion = match[1];
}


// when our AccountBar is available , peform the replacement. 
$.when(pageLoading).then(function($obj) {
    var from = 'splunk_for_hadoopops',
        to  = 'HadoopOps',
        selector = (splVersion > 5) ? '#global-help-menu li:contains("Documentation") a' : '.HadoopOpsAppBar a.help',
        $target = ($obj)? $obj: $(selector),
        helpLink = $target.attr("href"),
        versionRex = /%3A(\d+)\.(\d+)(?:\.(\d+))?%5D/,
        matches = helpLink.match(versionRex),
        maj = matches[1],
        min = matches[2],
        rev = matches[3],
        maj_min_rev = [maj,min,rev].join("."),
        maj_min = [maj,min].join(".");

    helpLink = helpLink.replace(from,to);

    // if we have a 3-digit version x.0.0 then replace with x.0
    if( min === "0"  && min === rev) {
        helpLink = helpLink.replace(maj_min_rev,maj_min);
    }
   
    $target.attr("href",helpLink);
});

if(splVersion > 5) {
    // HADOOP-1055. Adjust AppBar in Splunk 6+ 
    $('.HadoopOpsAppBar').css("padding","0px");

    poller = setInterval(function(){
        var $spl6Help = $('#global-help-menu li:contains("Documentation") a'),
            helpLink = $spl6Help.attr("href"),
            version = /%3A(\d+)\.(\d+)(?:\.(\d+))?%5D/;
        
        // we need to wait for the element to exist and also for the contents to 
        // contain the version number... ugly ... but no event hooks :(
        if($spl6Help.length > 0 && helpLink.match(version)) {
            pageLoading.resolve($spl6Help);
            clearInterval(poller);
        }
    },200);
} else {
    // resolve immediately on Splunk 5. No async-client rendering to deal with
    pageLoading.resolve()
}



switch (Splunk.util.getCurrentView()) {

    case 'jobs_running': case 'job_history': 

        // deal with special case drilldowns for job views
        if (Splunk.Module.SimpleResultsTable) {

            Splunk.Module.SimpleResultsTable = $.klass(Splunk.Module.SimpleResultsTable, { 

                initialize: function($super, container) {
                    $super(container);
                    this.drilldown_container = $('.DrilldownRow');
                    this.offset = this.getOffset();
                    this.text = null;
                    $('tr', this.container).bind('click', this.onRowClick.bind(this));
                },

                getOffset: function() {
                    if (Splunk.util.getCurrentView() === 'jobs_running') {
                        return 55;
                    } else {
                        return 35;
                    }
                },

                onContextChange: function($super) {
                    this.hideAll();
                    $super();
                },

                getModifiedContext: function() {
                    var context = this.getContext(),
                        click = context.get('click') || {},
                        form = context.get('form'),
                        search = context.get('search'),
                        time_range = search.getTimeRange();

                    
                    if (this.text !== null) {
                        search.abandonJob();
                        form['earliest'] = time_range.getEarliestTimeTerms();
                        form['latest'] = time_range.getLatestTimeTerms();
                        form['job_id'] = this.text;
                        click['name'] = this.moduleId;
                        context.set('click', click);
                        context.set('form', form);
                        context.set('search', search);
                    }
                
                    return context;
                },

                hideAll: function() {
                    this.drilldown_container.hide();
                    this.hideDescendants(this.DRILLDOWN_VISIBILITY_KEY + '_' + this.moduleId);
                    this.setDrilldownTop(null);
                },

                isReadyForContextPush: function($super) {
                    if (this.text === null) {
                        return Splunk.Module.CANCEL;
                    }
                    return Splunk.Module.CONTINUE;
                },

                onRowClick: function($super, e) {
                var $target = $(e.target),
                        $parent = $target.parent(),
                        $g_parent = $parent.parent(),
                        $sibling = $parent.siblings('.expanded'),
                        text = $parent.children('td[field="job_id"]').text();

                    e.preventDefault();
                    if (e.target.nodeName !== 'TD') {
                        return $super(e);
                    }
                    this.hideAll();
                    this.text = text;

                    $parent.toggleClass('expanded')
                      .children(':first-child')
                        .toggleClass('arrowOpen');

                    $sibling.toggleClass('expanded')
                      .children(':first-child')
                        .toggleClass('arrowOpen');

                    if ($parent.hasClass('expanded') === true) {
                        this.showAll($target.offset()['top'] + this.offset);
                    } 
                    this.pushContextToChildren();
                },

                renderResults: function($super, htmlFragment) {
                    var results;
                    $super(htmlFragment);
                    results = $('tr', this.container);
                    if (results.length == 2) {
                        results.eq(1).children(':first-child').trigger('click'); 
                    }
                },

                setDrilldownTop: function(pos) {
                    if (pos !== null && pos !== undefined) {
                        this.drilldown_container.css('position', 'absolute')
                            .css('top', pos);
                    } else {
                        this.drilldown_container.css('position', 'relative')
                            .css('top', '0');
                    }
                },

                showAll: function(pos) {
                    this.setDrilldownTop(pos);
                    this.drilldown_container.show();
                    this.showDescendants(this.DRILLDOWN_VISIBILITY_KEY + '_' + this.moduleId);
                }

            });
        }
        break;

    case 'nodes':

        if (Splunk.Module.SimpleResultsTable) {

            Splunk.Module.SimpleResultsTable = $.klass(Splunk.Module.SimpleResultsTable, {

                DEFAULT_SPARKLINE_SETTINGS: {
                    type: 'line',
                    lineColor: '#6696c4',
                    lineWidth: '1.5',
                    width: '100',
                    highlightSpotColor: null,
                    minSpotColor: null,
                    maxSpotColor: null,
                    spotColor: null,
                    fillColor: null
                }

            });
        }

        if (Splunk.Module.StaticContentSample) {
            
            Splunk.Module.StaticContentSample = $.klass(Splunk.Module.StaticContentSample, {

                onContextChange: function($super) {
                    var context = this.getContext(),
                        click = context.get('click') || null,
                        form = context.get('form') || null,
                        prev = this.container.prev(),
                        node_indicator = d3.select(prev.get(0)).select("svg");
 
                    if (click !== undefined && click !== null) {
                        this.hide('CLICK KEY');
                        if (form !== null 
                          && form['host'] !== null
                          && form['host'] !== undefined) {
                            node_indicator.select("g").select("text").text(form['host']);
                            node_indicator.select("g").select("title").text(form['host']);
                        }
                        $(prev).show();
                        this.showDescendants('CLICK KEY');
                    } else {
                        this.hideDescendants('CLICK KEY');
                        $(prev).hide();
                        node_indicator.select("g").select("text").text("---");
                        node_indicator.select("g").select("title").text("---");
                        this.show('CLICK KEY');
                    }
                }

            });
        }

        // position the detail panel at top of the visible area
        $(window).scroll(function() {
            var win_top = parseInt($(window).scrollTop()) + 70,
                max_top = parseInt($(".NodesContainer").height()) - 485,
                $detail = $(".NodeDetail"),
                t = Math.min(Math.max(win_top, 250), max_top);
            $detail.css("top", t + 'px');
        });

        // the module calls resize on its own container
        // this is where we hook in to resize the main container
        $(".HadoopOpsNodes").bind("resize", function() { 
            $(".NodesContainer").height($(this).height() * 1.4);
        });

        // keep things looking relatively neat 
        $(window).bind("resize", function() {
            var w = $(window).width(),
                tmp;

            // quit resizing at 1175px 
            if (w > 1174) {
                $(".NodesContainer").css("width", "97%")
                    .css("margin-left", "auto");
                $(".NodeStatus").css("width", parseInt(w-80));
                $(".NodeDetail").css("left", w - 350).show();
                $(".NodeControl").css("min-width", w - 415).show();
            } else {
                $(".NodesContainer").css("width", "1150");
                $(".NodeStatus").css("width", 1175);
                $(".NodeDetail").css("left", 850).show();
                $(".NodeControl").css("min-width", 800).show();
            }
        });
        break;

    case 'home':

        // ensure consistent style between Splunk 4.x and 5.x 
        if ($('body').hasClass('splVersion-4') === true) {
            $('.SingleValue .singleResult').css('vertical-align', '-4px');
        }
     
        // keep the 'refreshed' meta information consistent on headlines panel
        $(document).ready(function() {
            var $meta = $('.panel_row2_col').children(':first-child').find('.meta'),
                $span = $('<span>').addClass('splLastRefreshed'),
                $belm = $('<b>').text('real-time');
            $span.append($belm);
            $meta.append($span);
        });
    
        // make the look consistent whether displaying 2 or 3 rows in the activities panel
        if (Splunk.Module.HadoopOpsSingleRowTable) { 
               
            Splunk.Module.HadoopOpsSingleRowTable = $.klass(Splunk.Module.HadoopOpsSingleRowTable, {
                
                onContextChange: function($super) {
                    if (this.moduleId==="HadoopOpsSingleRowTable_2_2_0") {
                        if (this.getContext().get("search").getTimeRange().isRealTime()) {
                            this.hide('TOGGLE VISIBILITY'); 
                            this.container.parent()
                                .find('.HadoopOpsSingleRowTable:visible:last')
                                  .find('.HadoopOpsSingleRowTableInner').addClass('islast');
                            $(this.container).closest('.HadoopOpsSingleRowTable')
                        } else { 
                            this.container.parent()
                                .find('.HadoopOpsSingleRowTable:visible:last')
                                  .find('.HadoopOpsSingleRowTableInner').removeClass('islast');
                            this.show('TOGGLE VISIBILITY'); 
                }
                    } 
                    $super(); 
                }
           }); 
        }

        // wire up hidden search to listen for context changes pushed upwards
        // in order to dispatch its search again
        if (Splunk.Module.HiddenSearch) {

            Splunk.Module.HiddenSearch = $.klass(Splunk.Module.HiddenSearch, {

                applyContext: function(context) {
                    var search = context.get('search');
                    search.job.cancel();
                    search.abandonJob();
                    this.pushContextToChildren();
                }

            });
        }
        break;
}

/**
 * Customize the message module so it wont constantly be telling the user 
 * things that they dont care about and things that might alarm them.
 */
if (Splunk.Module.Message) {
    Splunk.Module.Message= $.klass(Splunk.Module.Message, {
        getHTMLTransform: function($super){
            var argh = [ 
                /*{contains:"The system is approaching the maximum number of historical", level:"warn"},
                {contains:"Assuming implicit lookup table with filename", level:"info"},
                {contains:"Your timerange was substituted", level:"info"},
                {contains:"Specified field(s) missing from results", level:"warn"},
                {contains:"Field extractor", level:"warn"},
                {contains:"Unable to find an eventtype", level:"warn"},
                {contains:"Ignoring eventtype", level:"warn"},*/
                {contains:"Subsearches of a real-time search run over all-time", level:"info"}
            ],  
            messages, message;

            // backwards compatibility due to Message module change
            if (this.displayedMessages !== undefined) {
                messages = this.displayedMessages; 
            } else messages = this.messages;

            for (var i=0; i<messages.length;){
                message = messages[i];
                for (var j=0; j<argh.length; j++) {
                    if (message !== undefined 
                    && (message.content.indexOf(argh[j]["contains"])!=-1) 
                    && (message.level == argh[j]["level"])) { 
                        messages.splice(i, 1);
                        // decrement the counter to account for the splice
                        i--;
                        break;
                    } 
                }   
                i++;
            }
            
            if (this.displayedMessages !== undefined) {
                this.displayedMessages = messages;
            } else this.messages = messages;
            
            return $super();
        }   
    }); 
}