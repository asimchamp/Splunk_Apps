Splunk.Module.HadoopOpsAppBar = $.klass(Splunk.Module.AppBar, {

});
