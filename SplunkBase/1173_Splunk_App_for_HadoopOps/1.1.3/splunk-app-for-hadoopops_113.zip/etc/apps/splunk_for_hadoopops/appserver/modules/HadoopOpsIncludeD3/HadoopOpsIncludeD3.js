Splunk.Module.HadoopOpsIncludeD3 = $.klass(Splunk.Module, {
    initialize: function($super, container) {
        $super(container);
        this.hide('HIDDEN MODULE KEY');
    }
});

