(function(d3, _){

/* 
 * Requires IncludeD3 and IncludeUnderscore modules
 */

	Splunk.Module.HadoopOpsGauge = $.klass(Splunk.Module.DispatchingModule, {

  /* 
   *  Splunk.Module function overrides + implementation
   */
	initialize : function($super, container) {
		$super(container);

		var parent = this.container.parent(),
			lazyResize = _.debounce(this.resize,100),
      handleClick = _.bind(this.handleClick,this);
	
		this.$container = $(this.container);
		this.$el = $('#' + this.moduleId);

    // initialize params with defaults and overlay values from 
    // our view.xml 
    this.params = this.initParams({
      "gaugeColors":  "[0x79c442, 0xffd800,0xff8a00,0xd93705]",
      "rangeValues": "[0,50,65,89,100]",
      "valueFormat": "float" ,
      "gaugeTitle":  "Chart Title"
    });

    // graph is initialized in this.initGraph()
		this.graph = this.initGraph({
			initialized: false,
			rendered: false,
			domain: undefined,
			range: undefined,
			color: undefined,
			ratio: 5/4, 
			width: 200,
			height: 250,
			r: 200/2,
			scale: 1
		});


		// will execute only 1x per 100 msec
		$(window).resize(_.bind(lazyResize,this)); 

    // bind event handlers
    this.$el.find("svg.gauge").bind("click", handleClick);

		this.logger.info(this.moduleType, "Initialized module...");
	},

  getResultURL : function() {

    var context = this.getContext(),
      search = context.get("search"),
      search_param = search.getPostProcess() || "",
      base_url = search.getUrl("results"),
      params = {
        outputMode : "json",
        search : search_param
      },
      url = (search.job.isDone()) ? base_url : base_url + "_preview",
      param_str = "?" + Splunk.util.propToQueryString(params);

    return url + param_str;

  },

  isReadyForContextPush: function() {
      var isClicked = this.clicked;
      
      // ensure we set clicked back to it's original value
      this.clicked = false; 
      return (isClicked)? Splunk.Module.CONTINUE : Splunk.Module.CANCEL;
  },

  onJobDone : function() {
    this.getResults();
  },

  onJobProgress: function() {
    var job = this.getContext().get("search").job;

    if (job.isRealTimeSearch()) this.getResults();
    
  },

  renderResults : function(jsonRsp) {

    var results = JSON.parse(jsonRsp),
      datum = results[0],
      graph = this.graph,
      scale = graph.scale
      isFirstTime =  !graph.rendered,
      data_fill = { fill: true, x: 0, y0: 0 , empty: true };

    // handle odd case where someone has returned a non-numeric result for a gauge
    results.forEach(function(d) {
        d.empty = (isNaN(d.x))? true: false;
        d.x = (d.empty) ? 0 : +d.x;
    });

    // scale down our value to less than the max specified in our params
    data_fill.x = _.max([graph.max - datum.x, 0]); 

    // after we receive data change from "--- " to 0 which is a valid
    // integer.  Gauge transition interpolation needs 2 valid integers
    if(isFirstTime) {
      graph.svg.select(".chart-value")
        .text(this.formatValue(datum.x))
    }

    // invoke graph update method
    this.update([datum,data_fill]);

    graph.rendered = true; 
  },

  resetUI : function() {},

  /* 
   *  Module-specific implementation and methods
   */

  formatValue: function(val) {
    var format = this.params.valueFormat,
      output = Math.round(val);

    switch(format) {
      case "float":
      output = Math.round(val*100)/100
      break;
      case "percentage":
      output = Math.round(val) + "%"
      break;
      case "integer":
      output = Math.round(val)
      break;
    }

    return output;
  },

  handleClick: function() {
    var context = this.getContext();
    this.clicked = true; 
    context.set("click", this.moduleId);
    this.pushContextToChildren(context);
  },

  // helper method to convert our module config params to d3 compatible
  // structures. 
  _parser: function(key) {
    return d3.csv.parseRows(this[key].replace(/[\[\]\s]/g,"")
      .replace(/0x/g,"#"))[0];
  },

	// initialize graph,range,domain,scale. return d3 scale to caller.
	initGraph: function(options) {

    var graph = options,
      _parse = _.bind(this._parser,this.params),
      width = this.$el.width(),
      height = width * graph.ratio,
      title = this.params["gaugeTitle"]
			DEG_TO_RAD = Math.PI / 180,
			data_fill = { fill: true, x: 0, y0: 0 };

		// convert range and domain strings to arrays that d3 can use
		graph.range = _parse("gaugeColors");

		// d3 threshold scales do not inlcude the start or end of domain. 
		// per definition it only records transitions. therefore we remove
		// the ends and store them as min/max. we assume our input range
		// does not list a maxValue
		graph.domain = _parse("rangeValues");
		graph.min = graph.domain.shift();
		graph.max = graph.domain.pop();

		// voila we have a linear scale that can convert anything in our 
		// domain into a hex color. thanks 8th grade math!
		graph.color = d3.scale.threshold()
  			.domain(graph.domain)
  			.range(graph.range);

		graph.arc = d3.svg.arc()
        .outerRadius(graph.r - 5)
        .innerRadius(graph.r - 26);

    graph.pie = d3.layout.pie()
      .sort(null)
      .value(function(d) { return d.x; })
      .startAngle( -150 * DEG_TO_RAD)
      .endAngle( (150) * DEG_TO_RAD);

    // TODO: svg height attr and css height don't agree... seems css height wins
    graph.svg = d3.select("#" + this.moduleId + " svg")
        .attr("viewBox", [0,0,graph.width,graph.height].join(" ") )
        .attr("preserveAspectRatio", "xMidYMid meet")
        .attr("width", width)
        .attr("height",height)
      .append("g")
        .attr("class", "graph")
        .attr("transform", "translate(" + graph.r + "," +  graph.r + ")");

    graph.svg.append("text")
      .attr("y", 125)
      .text(title)
      .attr("dy",".25em")
      .attr("class", "chart-title Roboto-normal-100")
      .attr("text-anchor", "middle");

    // our text will be "---" until we start receiving data from our search
    graph.svg.append("text")
    .attr("dy",".25em")
    .attr("class", "chart-value Roboto-normal-300")
    .attr("text-anchor", "middle")
    .text("---");

    // just feed a piece of dummy data to fill the full arc
    graph.svg.selectAll(".arc-base")
    .data(graph.pie([{x:1}]))
    .enter()   
    .append("path")
      .attr("d", graph.arc)
      .attr("class", "arc-base")
      .attr("filter", 'url(#GaugeDropShadow_' + this.moduleId + ')');

    graph.initialized = true; 
		return graph;
	},

	initParams: function(opts) {

		var params = opts,
      context = this.getContext(),
			module = this; 

    _.each(opts, function(val,key){ 
			var param = module.getParam(key) || context.get(key);

			// check if our param is undefined, if so, use the default val
			// if the default val is of type Number , then we want to convert
			// the param value from String to Number
			param = (_.isUndefined(param) || _.isNull(param)) ? val : param;
			param = (_.isNumber(val)) ? parseInt(param,10) : param; 

		 	// set the property on the module to the layered value
		 	opts[key] = param;
		});

    opts.initialized = true;
    return opts; 
	},

  resize: function() {
    var height = this.container.height(),
      width = this.container.width(),
      selector = "#" + this.moduleId + " svg",
      svg = d3.select(selector);

    console.log("resize: ", width, height , this.$el.find('svg'));
    svg.attr("width", width).attr("height", height);
  },

  update: function(data) {
    // our data is made up of a single value and then 
    // a filler which we supply for compatibility with the pie() layout.
    var graph = this.graph,
      modname = this.moduleId,
      formatter = _.bind(this.formatValue,this),
      color = graph.color,
      pie = graph.pie,
      svg = graph.svg,
      arc = graph.arc,
      head_1 = [data[0]],
      pie_data = pie(data),
      pie_1 = pie(head_1),
      base,label,slices;

    // perform data binding
    label = svg.selectAll(".chart-value")
      .data(head_1);
      
    slices = svg.selectAll(".arc")
      .data(pie_data);

    // perform enter operations 
    slices.enter()
      .append("path")
        .attr("filter", 'url(#softfill_' + modname + ')')
        .attr("class", function(d){
          var type = (d.data.fill) ? "fill" : "data";
          return "arc " + type;})
        .style("fill", function(d) { 
          return (d.data.fill) ? "#FFFFFF" : color(d.data.x);})
        .attr("d",arc)
        .each(function(d) { this._current = d; });

    // perform update operations  
    label.transition()
      .duration(2000)
      .ease('linear')
      .tween("text", function(a) {
        // lets just be lazy cheaters and strip out % no matter what
        var from =  this.textContent.replace("%",""),
          to = a.x,
          i = d3.interpolate(from,to);
        return function(t) {
          this.textContent = formatter(i(t));
        };
      });

    // Store the displayed angles in _current.
    // Then, interpolate from _current to the new angles.
    // During the transition, _current is updated in-place by d3.interpolate.  
    
    slices.transition().duration(2000)
      .attrTween("d", function(a) {
        var i = d3.interpolate(this._current, a);
        this._current = i(0);
        return function(t) {
          return arc(i(t));
        };})
      .style("fill", function(d) { 
          return (d.data.fill) ? "#FFFFFF" : color(d.data.x);
        });
  }

});

})(d3, HadoopOpsUnderscore);
