from django.contrib.auth.decorators import login_required
from splunkdj.decorators.render import render_to

@render_to('wifi_defcon_1:home.html')
@login_required
def home(request):
    return {
        "message": "Hello World from wifi_defcon_1!",
        "app_name": "wifi_defcon_1"
    }