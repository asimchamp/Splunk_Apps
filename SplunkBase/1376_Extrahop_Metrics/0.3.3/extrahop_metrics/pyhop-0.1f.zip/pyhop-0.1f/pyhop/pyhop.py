'''
pyhop.py - make it simple to connect to a Extrahop system
and use the API.

Written by Matt Cauthorn for Extrahop Networks, Inc.
This software is shipped as-is, with no guarantees or warranty.
Contributors: Tanya Bragin (major), Kevin Senguin

Requires pyamf.
'''

import getpass
import httplib
import optparse
import re
import sys
import time
import urllib
import types
import socket
import struct

import pyamf
from pyamf import remoting

AGENT = 'Extrahop API Client'
AUTH_URI = "/extrahop/login/"
ENV_URI = '/1'

__version__ = 0.13

# Helper functions
def get_time(t):
    ''' Converts time into a friendly format '''
    return time.ctime(long(t)/1000)

def get_ip(a):
    ''' Converts the pyamf ip objects into something readable '''
    if isinstance(a, types.StringTypes):
            # already a string, no formatting required
        return a
    elif not isinstance(a, pyamf.amf3.ByteArray):
        # unexpected type
        raise ValueError
    ipaddr = str(a)
    size = len(ipaddr)
    if size == 4:
        return socket.inet_ntop(socket.AF_INET, ipaddr)
    elif size == 16:
        return socket.inet_ntop(socket.AF_INET6, ipaddr)
    else:
        raise ValueError

def get_mac(m):
    ''' Converts the pyamf mac objects into something readable '''
    if isinstance(m, types.StringTypes):
        # already a string, no formatting required
        return m
    elif not isinstance(m, amf3.ByteArray):
        # unexpected type
        raise ValueError
    bytes = struct.unpack('BBBBBB', str(m))
    return "%02X:%02X:%02X:%02X:%02X:%02X" % bytes


class Client(object):
    '''
    The main class for import, allows you to interact with Extrahop.
    Keyword Args:
    @user or username
    @passwd or password
    @hostname or host
    '''

    def __init__(self, user=None, username=None, passwd = None, password=None,hostname=None, host=None):

        self.user = user or username
        self.passwd = passwd or password
        self.host = host or hostname
        self._login()
        pyamf.register_class_loader(self.default_class_loader)

    def default_class_loader(self,alias): return pyamf.ASObject

    def logout(self):
        headers = {"User-Agent": AGENT, "Cookie": "sessionid=" + self.  sessionid}
        self.conn.request('GET', '/extrahop/logout/', "", headers)
        rsp = self.conn.getresponse()

    # decorator for the special funcs. Twisted my brain on this, but
    # it was well worth the exercise...

    def decorate(ex_target):
        def wrap(f):
            def wrapper(self,*args,**kwargs):
                return self._send_request(ex_target,*args)
            return wrapper
        return wrap

    # private methods.
    def _login(self):
        ''' the main login request '''
        self._set_auth_headers()
        #self.conn = httplib.HTTPSConnection(self.host)
        self.conn = self._get_connection(self.host)
        self.conn.request("POST",AUTH_URI, self.login,self.authheaders)
        rsp = self.conn.getresponse()
        rsp.read()

        if rsp.status == 401:
            print "login failed"
            sys.exit(1)

        self._set_sessionid(rsp)

    def _get_connection(self, host):
        ''' returns a new httplib connection object to work around bugs in httplib'''
        connection = httplib.HTTPSConnection(self.host)
        return connection

    def _set_login(self):
        ''' sets up the login creds '''
        self.login = urllib.urlencode({"username": self.user,
            "password": self.passwd})

    def _get_sessionid(self,cookie):
        ''' Get the sessionid from the login response '''
        r = re.compile('sessionid=([^;]*);')
        sess = r.search(cookie)
        if sess:
            return sess.group(1)
        else:
            return None

    def _set_sessionid(self, rsp):
        ''' Set the session cookie attribute. Needs a response object'''
        self.sessionid = self._get_sessionid(rsp.getheader('Set-Cookie'))

    def _set_auth_headers(self):
        ''' sets up the headers for the auth request '''
        self._set_login()
        self.authheaders = {"Content-Type": "application/x-www-form-urlencoded",
                "Content-Length": len(self.login),
                "User-Agent": AGENT}

    def _send_request(self, target, *args):
        ''' wrapper method to send the actual stats request '''
        uri = "/1"
        req_envelope = remoting.Envelope(pyamf.AMF3)
        req_envelope[uri] = remoting.Request(target, args)
        body = remoting.encode(req_envelope).getvalue()
        headers = {"Content-Type": remoting.CONTENT_TYPE,
                   "Content-Length": len(body),
                   "User-Agent": AGENT,
                   "Cookie": "sessionid=" + self.sessionid}
        # This part makes me cry inside. For some reason httplib won't
        # honor the connection state and we have to play games like this.
        # TODO: review the chunk below closely and remove not needed stuff.
        try:
          self.conn.request("POST", "/a/", body, headers)
          rsp = self.conn.getresponse()
        except (httplib.BadStatusLine, httplib.CannotSendRequest), e:
          #self._login()
          self.conn = self._get_connection(self.host)
          self.conn.request("POST", "/a/", body, headers)
          rsp = self.conn.getresponse()

        content_type = rsp.getheader("Content-Type")
        if (rsp.status == 200) and (content_type == remoting.CONTENT_TYPE):
            amf_rsp = remoting.decode(rsp.read())[uri]
            if amf_rsp.status == remoting.STATUS_OK:
                return amf_rsp.body
            else:
                raise Exception, str(amf_rsp.body)
        else:
            raise Exception, "response error: " + str(rsp.status)

    # End private methods. Decorated calls below.
    # The format for each one is the same: @decorate('amf.Method')
    # def foo(self, *args)
    #     pass

    @decorate("bridge.getExStats")
    def get_exstats(self, *args):
        ''' Get an exstats request - raw metrics for a device '''
        pass

    @decorate("bridge.getExStatsGroup")
    def get_exstats_group(self, *args):
        ''' Get raw stats for a group of devices '''
        pass

    @decorate("bridge.getExStatsTotal")
    def get_exstats_total(self, *args):
        ''' '''
        pass

    @decorate("config.getCaptures")
    def get_captures(self,*args):
        pass

    @decorate("config.getAllDevices")
    def get_all_devices(self, *args):
        pass

    @decorate("config.getDevices")
    def get_devices(self, *args):
        pass

    @decorate("config.getDevicesWithActivity")
    def get_devices_with_activity(self, *args):
        pass

    @decorate("config.getDevice")
    def get_device(self, *args):
        pass

    @decorate("config.getActiveDevices")
    def get_active_devices(self, *args):
        pass

    @decorate("config.searchDevicesByActivity")
    def search_devices_by_activity(self, *args):
        pass

    @decorate("config.searchDevicesByType")
    def search_devices_by_type(self, *args):
        pass

    @decorate("config.searchDevicesByAny")
    def search_devices_by_any(self, *args):
        pass

    @decorate("config.searchDevicesByName")
    def search_devices_by_name(self, *args):
        pass

    @decorate("config.searchDevicesByIP")
    def search_devices_by_ip(self, *args):
        pass

    @decorate("config.searchDevicesByMAC")
    def search_devices_by_mac(self, *args):
        pass

    @decorate("config.searchDevicesByVendor")
    def search_devices_by_vendor(self, *args):
        pass

    @decorate("config.searchDevicesByTag")
    def search_devices_by_tag(self, *args):
        pass

    @decorate("config.searchDevicesByVlan")
    def search_devices_by_vlan(self, *args):
        pass

    @decorate("config.getDeviceGroups")
    def get_device_groups(self, *args):
        pass

    @decorate("config.getDeviceGroupDevices")
    def get_device_group_devices(self, *args):
        pass

    @decorate("bridge.getDeviceActivity")
    def get_device_activity(self, *args):
        pass

    @decorate("config.getDevicesByType")
    def get_devices_by_type(self, *args):
        ''' Confirm this works.'''
        pass

    @decorate("config.getActivityGroupsCount")
    def get_activity_groups_count(self, *args):
        pass

    @decorate("config.getActivityGroupsCount")
    def get_activity_groups_count(self, *args):
        pass

    @decorate("config.getDynamicGroupDevices")
    def get_dynamic_group_devices(self, *args):
        pass

    @decorate("config.getDeviceTags")
    def get_device_tags(self, *args):
        pass

    @decorate("config.updateDevice")
    def update_device(self, *args):
        pass

    @decorate("config.newDeviceGroup")
    def new_device_group(self, *args):
        pass

    @decorate("config.deleteDeviceGroups")
    def delete_device_groups(self, *args):
        pass

    @decorate("config.updateDeviceGroup")
    def update_device_group(self, *args):
        pass

    @decorate("config.addDeviceGroupMembers")
    def add_device_group_members(self, *args):
        pass

    @decorate("config.removeDeviceGroupMembers")
    def remove_device_group_members(self, *args):
        pass

    @decorate("config.updateDeviceGroupMembers")
    def update_device_group_members(self, *args):
        pass

    @decorate("config.deviceTagAdd")
    def device_tag_add(self, *args):
        pass

    @decorate("config.deviceTagRemove")
    def device_tag_remove(self, *args):
        pass

    @decorate("config.deviceTagRename")
    def device_tag_rename(self, *args):
        pass

    @decorate("config.deviceTagDelete")
    def device_tag_delete(self, *args):
        pass

    @decorate("config.getTriggers")
    def get_triggers(self, *args):
        ''' Gets the active list of triggers'''
        pass

    @decorate("config.getTrigger")
    def get_trigger(self, *args):
        ''' Gets a specific trigger'''
        pass

    @decorate("config.setTrigger")
    def set_trigger(self, *args):
        ''' Sets a specific trigger'''
        pass

    @decorate("config.deleteTrigger")
    def delete_trigger(self, *args):
        ''' Deletes a specific trigger'''
        pass

    @decorate("config.removeTrigger")
    def remove_trigger(self, *args):
        ''' Deletes a specific trigger'''
        pass

    @decorate("config.getAlerts")
    def get_alerts(self, *args):
        ''' Gets alerts'''
    pass  

    @decorate("mgmt.saveSSLDecryptionKey")
    def save_ssl_decryption_key(self, *args):
        ''' Saves SSL decryption key'''
    pass  

    @decorate("config.newDynamicDeviceGroup")
    def new_dynamic_device_group(self, *args):
        ''' Creates a new dynamic device group'''
    pass  

    @decorate("config.updateDynamicDeviceGroup")
    def update_dynamic_device_group(self, *args):
        ''' Updates a dynamic device group'''
    pass  

if __name__ == '__main__':
    import sys
    import pyhop
    c = pyhop.Client(host= sys.argv[1],user='admin',passwd='admin')
    result = c.get_captures(0)
    print result

