from distutils.core import setup

setup (
    name = "PyHop",
    author="Matt Cauthorn",
    url = "http://www.extrahop.com",
    author_email="matt@extrahop.com",
    version = "0.13",
    packages = ["pyhop"],
    license = "LICENSE",
    description = "A helper module for interacting with Extrahop systems",
    long_description=open("README").read()

)
