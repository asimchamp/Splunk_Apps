#!/bin/env python
'''
This script will pull the current list of devices, and then attempt to
resolve the names of all systems wihtout a populated IP address
in the list.
'''
# imports
import sys
import time
import socket
import pyhop.pyhop as p

# get client address
addr,user,passwd = sys.argv[1], sys.argv[2], sys.argv[3]

# Setup pyhop client and connect to a device.
c = p.Client(host=addr,user=username,passwd=passwd)


# First, grab the device list.
devs = c.get_all_devices()
