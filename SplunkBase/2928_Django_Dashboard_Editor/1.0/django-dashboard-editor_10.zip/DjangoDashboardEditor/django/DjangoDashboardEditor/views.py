from django.contrib.auth.decorators import login_required
from splunkdj.decorators.render import render_to
import os
import django
from django.http import HttpResponse
import json;


@render_to('DjangoDashboardEditor:home.html')
@login_required
def home(request):
    try:
        #Validate is the user has role for editing the template:
        service = request.service;
        roles = service.roles;
        CAPABLE_USER = False;
        for role in roles:
            for capability in role.capabilities:
                if 'edit_view_html' == capability:
                    CAPABLE_USER = True;
                    break;
            
                
        action= request.POST.get('action');
        if "GET_TEMPLATES" == action:
            appName = request.POST.get('appName');
            appPath = request.POST.get('appPath');
            templatesPath = os.path.join(os.path.join(os.path.join(appPath, 'django'), appName), 'templates');
            djangoTemplates = {};
            templateStatus = "";
            if os.path.exists(templatesPath):
                templates = os.listdir(templatesPath);
                for template in templates:
                    djangoTemplates[template] = os.path.join(templatesPath, template);
                templateStatus = "FOUND";
            else:
               templateStatus = "NOT_FOUND";

            DJANGO_TEMPLATES_META = {
                    "djangoTemplates" : djangoTemplates,
                    "TEMPLATE_STATUS" : templateStatus,
                }

            return HttpResponse(json.dumps(DJANGO_TEMPLATES_META), content_type="application/json")

        elif "LOAD_TEMPLATE" == action:
            templateName = request.POST.get('templateName');
            templatePath = request.POST.get('templatePath');
            templateContent = '';

            f = open(templatePath, 'r')
            try:
                for line in f:
                    templateContent = templateContent + line;
            finally:
                f.close();


            responseObj = {
                    "templateName" : templateName,
                    "templatePath" : templatePath,
                    "templateContent" : templateContent,
                }
            return HttpResponse(json.dumps(responseObj), content_type="application/json")

        elif "SUBMIT_TEMPLATE" == action:
            templateName = request.POST.get('templateName');
            templatePath = request.POST.get('templatePath');
            templateContent = request.POST.get('templateContent');

            f = open(templatePath, 'w+');
            STATUS='FAILURE';
            try:
                f.write(templateContent);
                STATUS='SUCCESS';
            finally:
                f.close();


            responseObj = {
                    "templateName" : templateName,
                    "templatePath" : templatePath,
                    "templateContent" : templateContent,
                    "STATUS" : STATUS,
                }
            return HttpResponse(json.dumps(responseObj), content_type="application/json")
            
        elif "GET_APPS" == action:
            DJANGO_ROOT = os.path.dirname(os.path.realpath(django.__file__));
            SITE_ROOT = os.path.dirname(os.path.realpath(__file__));
            TEMPLATES = os.path.join(SITE_ROOT, 'templates');
            APP_DIR = os.path.dirname(os.path.dirname(os.path.dirname(SITE_ROOT)));
            
            djangoApps = {};
            appNames = os.listdir(APP_DIR);
                
            for appName in appNames:
                appPath = os.path.join(APP_DIR, appName);
                if os.path.isdir(appPath):
                    appDirs = os.listdir(appPath);
                    for appDir in appDirs:
                        if appDir == "django":
                            djangoApps[appName] = appPath;
                            #djangoApps.append(appName);
                        else:
                            pass;
                else:
                    pass;
       
            #create meta information for apps.
            SPLUNK_META = {
                    "DJANGO_ROOT" : DJANGO_ROOT,
                    "SITE_ROOT" : SITE_ROOT,
                    "TEMPLATES" : TEMPLATES,
                    "APP_DIR" : APP_DIR,
                    "djangoApps" : djangoApps,
                    "CAPABLE_USER" : CAPABLE_USER,
                }

            
        
            return HttpResponse(json.dumps(SPLUNK_META), content_type="application/json")
            #return HttpResponse('Hello World Continued!');
        else:
            return {
                "message": "Hello World from DjangoDashboardEditor!",
                "app_name": "DjangoDashboardEditor",
            }
    except Exception, e:
        ERROR_OBJ = {
                "ErrorObj" : str(e)
            }
        return HttpResponse(json.dumps(ERROR_OBJ), content_type="application/json")
        
    
