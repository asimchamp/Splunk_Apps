// Copyright (C) 2010-2014 Sideview LLC.  All Rights Reserved.


var SideviewApp = {};
SideviewApp.name = "shotgun_reporting";
SideviewApp.licenseGenerated = 1430337729000;
SideviewApp.licenseLength = 315360000000;
SideviewApp.isPaidLicense = false;

function startupChecks() {
    
    var REQUIRED_VERSION = "3.3.2";
    var REQUIRED_SPLUNK_VERSION = "6.1";

    function displayError(errorId, redirectToHomeIfAbsent) {
        var error = $("#" + errorId);
        if (error.length>0) {
            error.show();
        } 
        else if (redirectToHomeIfAbsent) {
            // we're home but the error div isn't here...
            if (Splunk.util.getCurrentView()=="home"){ 
                alert("Unexpected Error: " + errorId);
            }
            else {
                document.location = "home";
            }
        }
    }

    function isSplunkTooOld() {
        if (!REQUIRED_SPLUNK_VERSION) return false;
        var currentSplunkVersion = Splunk.util.getConfigValue("VERSION_LABEL");
        if (Sideview.utils.compareVersions(currentSplunkVersion,REQUIRED_SPLUNK_VERSION) == -1) {
            $("#SplunkTooOld .currentVersion").text(currentSplunkVersion);
            $("#SplunkTooOld .requiredVersion").text(REQUIRED_SPLUNK_VERSION);
            return true;
        }
    }

    function isSideviewUtilsTooOld() {
        if (!REQUIRED_VERSION) return false;
        if (typeof(Sideview)!="undefined" && !Sideview.utils.checkRequiredVersion(REQUIRED_VERSION)){
            var currentVersion = Sideview.utils.getCurrentVersion();
            $("#SideviewUtilsTooOld .currentVersion").text(currentVersion);
            $("#SideviewUtilsTooOld .requiredVersion").text(REQUIRED_VERSION);
            return true;
        }
    }

    function isLicenseExpired() {
        var now        = new Date();
        var expireDate = new Date();
        expireDate.setTime(SideviewApp.licenseGenerated + SideviewApp.licenseLength);
        var expired = (now.valueOf() > expireDate.valueOf());
        if (expired) {
            $("#TrialVersionExpired .expirationTime").text(expireDate.toString());
            $("#FullVersionExpired .expirationTime").text(expireDate.toString());
        } else {
            $("#TrialVersionNotice .expirationTime").text(expireDate.strftime(" on %B %e, %Y"));
        }
        return expired;
    }

    function isPaidLicense() {
        return SideviewApp.isPaidLicense;
    }

    function isTrialLicense() {
        return (!SideviewApp.isPaidLicense && SideviewApp.licenseGenerated>0)
    }

    function isLicenseExpiring() {
        var now        = new Date();
        var expireDate = new Date();
        expireDate.setTime(SideviewApp.licenseGenerated + SideviewApp.licenseLength);
        var expiresInDays = Math.ceil((expireDate.valueOf() - now.valueOf())/(1000*3600*24));
        $("#TrialVersionExpiring .expirationDays").text(expiresInDays.toString());
        $("#FullVersionExpiring .expirationDays").text(expiresInDays.toString());
        $("#TrialVersionExpiring .expirationDate").text(expireDate.toString());
        $("#FullVersionExpiring .expirationDate").text(expireDate.toString());
        
        return (expiresInDays>0 && expiresInDays < 7);
    }
    function hasSideviewLicense() {
        return (SideviewApp.hasOwnProperty("licenseGenerated") && SideviewApp.licenseGenerated);
    }

    function legacyIsAppInstalled() {
        var appList = false;
        try {appList = Splunk.Module.loadParams.AccountBar_0_0_0.appList;}
        catch(e) {return -1;}
        if (!appList) return -1;
        for (var i=0,len=appList.length;i<len;i++) {
            if (appList[i].id == "sideview_utils") return 1;
        }
        return 0;
    }

    // Otherwise ModuleLoader fires a barrage of alerts that bewilder the user
    function buildStubModuleClasses() {
        var m = Splunk.Module;
        m.ArrayValueSetter = m.AutoRefresh = m.Button = m.CanvasChart = 
        m.Checkbox = m.Checkboxes = m.CheckboxPulldown = m.CustomBehavior = 
        m.CustomRESTForSavedSearch = m.DateTime = m.Events = m.Filters = 
        m.Gate = m.HTML = m.JobSpinner = m.LeftNavAppBar = m.Link = 
        m.Multiplexer = m.NavBar = m.Pager = m.PostProcess = m.Pulldown = 
        m.Radio = m.Redirector = m.Report = m.ResultsValueSetter = 
        m.SankeyChart = m.SavedSearch = m.Search = m.SearchControls = 
        m.ShowHide = m.SideviewUtils = m.Switcher = m.Table = m.Tabs = 
        m.TextField = m.Timeline = m.TreeMap = m.URLLoader = m.ValueSetter = 
        m.ZoomLinks = $.klass(m, {});
    }
    
    function checkVersions() {
        if (isSplunkTooOld()) {
            displayError("SplunkTooOld",true);
        }
        else if (isSideviewUtilsTooOld()) {
            displayError("SideviewUtilsTooOld",true);
        }
        if (isSideviewUtilsTooOld()) {
            buildStubModuleClasses()
        }
    }

    function checkLicense() {
        if (!hasSideviewLicense()) return;
        if (isTrialLicense()) {
            $("#TrialVersionNotice").show();
        }
        if (isLicenseExpired()) {
            if (isPaidLicense() ) {
                displayError("FullVersionExpired",true);
            } 
            else if (isTrialLicense()) {
                displayError("TrialVersionExpired",true);
                //Sideview.utils = {};
            }
        }
        else if (isLicenseExpiring()) {
            if (isPaidLicense() ) {
                $("#FullVersionExpiring").show();
            } else if (isTrialLicense()) {
                $("#TrialVersionExpiring").show();
            }
        }
    }
    // courtesy of always(), this will run for both success and failure.
    function appResultsHandler(jsonResponse) {
        var installedVersion = false;
        try {
            installedVersion = jsonResponse.entry[0].content.version;
        } catch(e) {
            //console.error("Either Sideview Utils is not installed on this server, or we couldn't get the version out of the REST API response");
        }
        if (!installedVersion) {
            // maybe the rest call failed only because we're on an ancient version.
            var isInstalled = legacyIsAppInstalled();
            if (isInstalled!=1) {
                displayError("SideviewAppNotInstalled",true);
                return;
            }
        }
        checkVersions();
        checkLicense();
    }
    
    // On pages like "search", Sideview will be undefined always. 
    if (typeof(Sideview)=="undefined") {
        // note: this URL will only work as far back as 5.0. 
        // in 4.3 and earlier the endpoint does not accept output_mode=json
        var url = Splunk.util.make_url("/splunkd/__raw/services/apps/local/sideview_utils?output_mode=json");
        $.get(url).always(appResultsHandler);
        buildStubModuleClasses();
    } else {
        checkVersions();
        checkLicense();
    }
}
startupChecks();
if (typeof(Sideview)!="undefined") {
    
    // worlds' smallest contextual help system. 
    // wrote the core code in about 90 seconds.
    // wheee
    function goToState(name) {
        $(".contextualHelp div").hide();
        $(".contextualHelp ." + name ).show();
    }


    // This customBehavior will almost certainly be replaced and quite soon, 
    // by a Sideview module called DeMultiplexer.
    var deMultiplexed = [];
    Sideview.utils.declareCustomBehavior("deMultiplexer", function(customBehaviorModule) {
        customBehaviorModule.onContextChange = function() {
            var context = this.getContext();
            var field = context.get("field");
            if (context.get("include")=="1") {
                var dict = {};
                dict["numeric"] = context.get("numeric");
                dict["dc"]      = context.get("dc");
                deMultiplexed[field] = dict;
            } else {
                delete deMultiplexed[field];
            }
        }
    });

    Sideview.utils.declareCustomBehavior("clearDeMultiplexed", function(customBehaviorModule) {
        customBehaviorModule.onContextChange = function() {
            deMultiplexed = [];
        }
    });
    

    Sideview.utils.declareCustomBehavior("collectDeMultiplexed", function(customBehaviorModule) {

        customBehaviorModule.isReadyForContextPush = function() {
            var fieldCount = 0;
            for (field in deMultiplexed) {
                if (deMultiplexed.hasOwnProperty(field)) {
                    fieldCount++
                }
            }
            if (fieldCount>2) return true;
            else goToState("atLeastNFields")
            
        }
        customBehaviorModule.getModifiedContext = function() {
            var context = this.getContext();
            var mess = [];
            for (field in deMultiplexed) {
                if (deMultiplexed.hasOwnProperty(field)) {
                    mess.push(field + ","+deMultiplexed[field]["dc"]+","+deMultiplexed[field]["numeric"])
                }
            }

            var cmd = ["| stats count | fields - count"];
            cmd.push("eval " + context.get("index"))
            cmd.push("eval " + context.get("sourcetype"))
            cmd.push("eval mess=split(\"" + mess.join(";") + "\",\";\") | mvexpand mess | eval mess=split(mess,\",\") | eval field=mvindex(mess,0) | eval dc=mvindex(mess,1) | eval numeric=mvindex(mess,2)");

            context.set("createLookupSearch",cmd.join (" | "));
            return context;
        }
    });

    Sideview.utils.declareCustomBehavior("changeAppContext", function(customBehaviorModule) {
        customBehaviorModule.onContextChange = function() {
            var context = this.getContext();
            var appContext = this.getParam("arg.appContext");
            appContext = Sideview.utils.replaceTokensFromContext(appContext, context);
            if (appContext) {
                $(document.body).attr("s:app",appContext);
            }
        }
    });

    Sideview.utils.declareCustomBehavior("greyOutRowWhenUnchecked", function(checkboxModule) {
        //var onPassiveChangeReference = checkboxModule.onPassiveChange.bind(checkboxModule);
        var setToContextValueReference  = checkboxModule.setToContextValue.bind(checkboxModule);
        
        

        checkboxModule.lightEmUp = function() {
            checkboxModule.container.removeClass("greyedOut");
            var radio = checkboxModule.container.next(".Radio");
            radio.removeClass("greyedOut");
            radio.find("input").removeAttr("disabled");
            radio.next(".HTML").removeClass("greyedOut");
        }
        checkboxModule.greyEmOut = function() {
            checkboxModule.container.addClass("greyedOut");
            var radio = checkboxModule.container.next(".Radio");
            radio.addClass("greyedOut");
            radio.find("input").attr('disabled','disabled');
            radio.next(".HTML").addClass("greyedOut");
        }

        checkboxModule.setToContextValue = function(context) {
            var retVal = setToContextValueReference(context);
            this.onPassiveChange();
            return retVal;
        }.bind(checkboxModule)

        checkboxModule.onPassiveChange = function() {
            var context = this.getContext();
            if (this.input.is(':checked')) {
                this.lightEmUp();
            } else {
                this.greyEmOut();
            }
        }

    });

    

}

if (Splunk.Module.Message) {
    Splunk.Module.Message= $.klass(Splunk.Module.Message, {
        scrubQueue: function() {
            var argh = [
                {contains:"Configuration initialization took", level:"warn"},
                {contains:"Results written to", level:"info"},
                {contains:"The lookup table", level:"info"},
                {contains:"The lookup table", level:"warn"},
                {contains:"The lookup table", level:"error"}
            ];
            for (var i=this.allMessages.length-1; i>=0; i--){
                var message = this.allMessages[i];
                for (var j=0,jLen=argh.length;j<jLen;j++) {
                    if ((message.content.indexOf(argh[j]["contains"])!=-1) && (message.level == argh[j]["level"])) {
                        this.allMessages.splice(i,1);
                        break;
                    }
                }
            }
            for (var i=this.displayedMessages.length-1; i>=0; i--){
                var message = this.displayedMessages[i];
                for (var j=0,jLen=argh.length;j<jLen;j++) {
                    if ((message.content.indexOf(argh[j]["contains"])!=-1) && (message.level == argh[j]["level"])) {

                        this.displayedMessages.splice(i,1);
                        break;
                    }
                }
            }
        },
        getHTMLTransform: function($super){
            
            this.scrubQueue();
            return $super();
        }
    });
}
